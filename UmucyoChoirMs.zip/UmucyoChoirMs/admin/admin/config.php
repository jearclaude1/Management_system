<?php

$conn = mysqli_connect('localhost','root','','umucyo_db') or die('connection failed');
//if($conn == true){
  // echo ("connected");
//}

?>